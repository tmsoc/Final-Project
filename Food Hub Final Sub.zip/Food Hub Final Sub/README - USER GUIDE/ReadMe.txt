# ReadMe

*Changes from the last submission:
The program has been completely built with 100% functionality. Owner window has been activated, so business owner can log in, perform some functions like: creating new restaurant, editing restaurant info, deleting restaurant. With Administrative function, admin can now update menus by just clicking the Menu Update button to open a link to the menu file, and now has the ability to delete restaurants. The customer functionality now allows users to add reviews.


The program is made to cater to 3 separate types of user: a standard user, a restaurant owner, and an administrator. 

The standard user has mainly passive interaction with the program. The only modifications the standard user will have the ability to make is to write and submit reviews to each of the restaurants. The current state of the standard user side of the program is mainly complete. The user has the ability to search for restaurants, filter restaurants by dietary options, and to see all specific details associated with the restaurant. Additional search abilities, for instance key words and location, the ability to view menus, and the ability to log in and submit a review still need to be implemented.

The administrative section is functional but still lacks the ability to modify any of the stored restaurant, user, or owner information. The graphical interface has been made and the windows to edit data have been made, but the ability to perform the edits and to save them still need to be implemented. Some of the methods needed have already been written, they just need to be connected to the user interface. 

The owner section of the program still requires the majority of the work needed. The graphical interface still needs to be written and some of the methods in the controller to execute the owner tasks still need to be written. This section of the program will allow owners to create or delete restaurant entries and the ability to import pdf menus. A lot of the back end code has been written, we just need to develop the graphical interface.

For the graphical interface we decided to use Tkinter. All of us had some experience with it so it made the best choice for this project. All the stored records are kept in a sqlite database, which seemed like the best option for this application. The ability to access the records from a database instead of text files was beneficial for us since we could pull, edit, and delete records without writing long algorithms to do the same with text files. The project was developed with the MVC architecture which did slow down the progress of how fast we were able to get developed in the beginning due to a learning curve.

The main.py file is the file required to run the program.

The View class written by Linh and improved by Tony
The Controller class was written by Simona and Tony
The Model class was written by Tony

To access the admin and owner parts of the program a user name and password is needed to access them. 
ADMIN:
admin, pep8

OWNERS:
Simona, pep8
Linh, pep8
Tony, pep8

The View class manges the following tables:
* restaurant table - 
    id - <int> Unique to the restaurant. Populated by the db.
    name - <string>
    address - <string>
    city - <string>
    state - <string>
    zip_code - <string>
    vegetarian - <bool>
    vegan - <bool>
    gluten - <bool>
    menu - <bool>
    hours - <string>
    description - <string>

* reviews table - 
    id - <int>
    user - <string>
    review - <string>
    rating - <int>
    date_time - <string>
    key - <int> Unique to the review. Populated by the db

* menus table - 
    id - <int>
    menu_path - <string>
    key - <int> Unique to the menu. Populated by the db

* user table -
    name - <string>
    password - <string>
    zip_code - <string>
    key - <int> Unique to the user. Populated by the db 

* owner table -
    name - <string>
    password - <string>
    restaurants - <string>
    key - <int> Unique to the owner. Populated by the db


* admin table - 
    name - <string>
    password - <string>    
    key - <int> Unique to the admin. Populated by the db
